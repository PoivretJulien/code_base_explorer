- Personal tools that generate a code base explorer in self contained html page.
- specifically for Zig projects template source code, ( support .txt .html .md and .zig  .zig.zon files ).
- designed for my personal need from glm 5.3
- stored there for archive ( no pedagogic purpose, it's just a tool )
- -h argument for complete documentation.

